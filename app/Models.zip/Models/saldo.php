<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class saldo extends Model
{
    use HasFactory;
    protected $fillable = [
        'efectivo',
        'qr',
        'venta_id',
        'compra_id',
    ];

}
