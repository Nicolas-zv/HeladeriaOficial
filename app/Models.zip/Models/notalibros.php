<?php

// app/Models/Notalibros.php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Notalibros extends Model
{
    use HasFactory;

    protected $table = 'notalibros';

    protected $fillable = ['metodo', 'user_id'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

   public function libros()
{
    return $this->belongsToMany(libros::class, 'libro_notalibros', 'notalibro_id', 'libro_id')
                ->withPivot('cantidad', 'precio_unitario', 'subtotal')
                ->withTimestamps();
}

}
